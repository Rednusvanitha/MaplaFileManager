package com.mapla.filemanager

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.webkit.MimeTypeMap
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.documentfile.provider.DocumentFile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.DateFormat
import java.util.Date

private val Page = Color(0xFFF4F5F8)
private val Card = Color(0xFFFFFFFF)
private val Ink = Color(0xFF202127)
private val Subtle = Color(0xFF777B86)
private val Blue = Color(0xFF3478F6)
private val Line = Color(0xFFE5E6EA)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaplaFileManagerApp() }
    }
}

private enum class HomeTab { RECENT, MY_FILES, BROWSE }
private enum class Category(val title: String, val mime: String?) {
    ALL("All files", null), IMAGES("Images", "image/"), VIDEOS("Videos", "video/"), DOCS("Docs", "application/"), AUDIO("Audio", "audio/"), APPS("Apps", "application/vnd.android.package-archive"), ARCHIVES("Archives", "application/zip")
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
private fun MaplaFileManagerApp() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var phoneRoot by remember { mutableStateOf<DocumentFile?>(null) }
    var usbRoot by remember { mutableStateOf<DocumentFile?>(null) }
    var leftFolder by remember { mutableStateOf<DocumentFile?>(null) }
    var rightFolder by remember { mutableStateOf<DocumentFile?>(null) }
    var dualPane by remember { mutableStateOf(false) }
    var activePane by remember { mutableIntStateOf(0) }
    var tab by remember { mutableStateOf(HomeTab.BROWSE) }
    var category by remember { mutableStateOf(Category.ALL) }
    var query by remember { mutableStateOf("") }
    var selection by remember { mutableStateOf(setOf<String>()) }
    var allFiles by remember { mutableStateOf<List<DocumentFile>>(emptyList()) }
    var showMore by remember { mutableStateOf<DocumentFile?>(null) }
    var showRename by remember { mutableStateOf(false) }
    var renameText by remember { mutableStateOf("") }
    var showDetails by remember { mutableStateOf(false) }
    var notice by remember { mutableStateOf("") }
    var pendingTransfer by remember { mutableStateOf("") }
    var selectedDetails by remember { mutableStateOf<DocumentFile?>(null) }

    fun currentFolder(): DocumentFile? = if (dualPane && activePane == 1) rightFolder else leftFolder
    fun setCurrent(folder: DocumentFile?) { if (dualPane && activePane == 1) rightFolder = folder else leftFolder = folder }
    fun refresh() {
        val folder = currentFolder()
        allFiles = folder?.listFiles()?.sortedWith(compareByDescending<DocumentFile> { it.isDirectory }.thenBy { it.name?.lowercase() }) ?: emptyList()
    }
    fun toast(text: String) { Toast.makeText(context, text, Toast.LENGTH_SHORT).show() }

    val phonePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            runCatching { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION) }
            phoneRoot = DocumentFile.fromTreeUri(context, uri)
            leftFolder = phoneRoot
            activePane = 0
            refresh()
        }
    }
    val usbPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            runCatching { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION) }
            usbRoot = DocumentFile.fromTreeUri(context, uri)
            rightFolder = usbRoot
            activePane = 1
            dualPane = true
            refresh()
        }
    }
    val destinationPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            runCatching { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION) }
            val destination = DocumentFile.fromTreeUri(context, uri)
            val sources = (if (dualPane && activePane == 1) rightFolder else leftFolder)?.listFiles()?.filter { selection.contains(it.uri.toString()) }.orEmpty()
            scope.launch {
                val result = withContext(Dispatchers.IO) {
                    var count = 0
                    sources.forEach { source ->
                        if (copyEntry(context, source, destination)) {
                            count++
                            if (pendingTransfer == "move") source.delete()
                        }
                    }
                    count
                }
                selection = emptySet()
                refresh()
                toast("$result item(s) ${if (pendingTransfer == "move") "moved" else "copied"}")
                pendingTransfer = ""
            }
        }
    }

    fun openFile(file: DocumentFile) {
        val mime = file.type ?: guessMime(file.name)
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(file.uri, mime)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        runCatching { context.startActivity(intent) }.onFailure { toast("No app can open this file") }
    }

    fun shareSelected() {
        val folder = currentFolder()
        val chosen = folder?.listFiles()?.filter { selection.contains(it.uri.toString()) }.orEmpty()
        if (chosen.isEmpty()) { toast("Select at least one file"); return }
        val uris = ArrayList<Uri>().apply { chosen.filterNot { it.isDirectory }.forEach { add(it.uri) } }
        if (uris.isEmpty()) { toast("Folders cannot be shared directly"); return }
        val intent = if (uris.size == 1) Intent(Intent.ACTION_SEND).apply {
            type = chosen.first().type ?: guessMime(chosen.first().name)
            putExtra(Intent.EXTRA_STREAM, uris.first())
        } else Intent(Intent.ACTION_SEND_MULTIPLE).apply {
            type = "*/*"
            putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
        }
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        context.startActivity(Intent.createChooser(intent, "Share files"))
    }

    MaterialTheme(colorScheme = lightColorScheme(primary = Blue, background = Page, surface = Card)) {
        Scaffold(
            containerColor = Page,
            bottomBar = {
                NavigationBar(containerColor = Card, tonalElevation = 4.dp) {
                    NavigationBarItem(selected = tab == HomeTab.RECENT, onClick = { tab = HomeTab.RECENT; selection = emptySet() }, icon = { Icon(Icons.Default.History, null) }, label = { Text("Recent") })
                    NavigationBarItem(selected = tab == HomeTab.MY_FILES, onClick = { tab = HomeTab.MY_FILES; selection = emptySet() }, icon = { Icon(Icons.Default.Folder, null) }, label = { Text("My files") })
                    NavigationBarItem(selected = tab == HomeTab.BROWSE, onClick = { tab = HomeTab.BROWSE; selection = emptySet() }, icon = { Icon(Icons.Default.FolderOpen, null) }, label = { Text("Browse") })
                }
            }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding)) {
                if (selection.isNotEmpty()) {
                    Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = { selection = emptySet() }) { Icon(Icons.Default.Close, "Clear selection") }
                        Text("${selection.size} selected", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                        IconButton(onClick = { selection = allFiles.map { it.uri.toString() }.toSet() }) { Icon(Icons.Default.SelectAll, "Select all") }
                    }
                } else {
                    Row(Modifier.fillMaxWidth().padding(horizontal = 22.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(if (tab == HomeTab.BROWSE) "Browse" else if (tab == HomeTab.RECENT) "Recent" else "My files", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.ExtraBold, modifier = Modifier.weight(1f))
                        if (tab != HomeTab.BROWSE) IconButton(onClick = { dualPane = !dualPane }) { Icon(Icons.Default.VerticalSplit, "Toggle dual pane") }
                        IconButton(onClick = { if (currentFolder() == null) phonePicker.launch(null) else notice = "Use the folder action below to create a folder" }) { Icon(Icons.Default.Add, "Add") }
                        IconButton(onClick = { notice = "Choose Phone or USB storage below. Long-press files to select." }) { Icon(Icons.Default.MoreVert, "More") }
                    }
                }

                if (tab == HomeTab.BROWSE && selection.isEmpty()) {
                    SearchBox(query, { query = it }, Modifier.padding(horizontal = 20.dp, vertical = 8.dp))
                    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 18.dp)) {
                        item {
                            Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                CategoryCard("Images", Icons.Default.Image, Color(0xFF2585E8), Modifier.weight(1f)) { category = Category.IMAGES; tab = HomeTab.MY_FILES }
                                CategoryCard("Videos", Icons.Default.VideoFile, Color(0xFFF39A19), Modifier.weight(1f)) { category = Category.VIDEOS; tab = HomeTab.MY_FILES }
                                CategoryCard("Docs", Icons.Default.Description, Color(0xFF19B66A), Modifier.weight(1f)) { category = Category.DOCS; tab = HomeTab.MY_FILES }
                            }
                        }
                        item {
                            Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 5.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                CategoryCard("Audio", Icons.Default.AudioFile, Color(0xFF8152E8), Modifier.weight(1f)) { category = Category.AUDIO; tab = HomeTab.MY_FILES }
                                CategoryCard("Apps", Icons.Default.Android, Color(0xFF1BB8B5), Modifier.weight(1f)) { category = Category.APPS; tab = HomeTab.MY_FILES }
                                CategoryCard("Archives", Icons.Default.FolderZip, Color(0xFFF06B28), Modifier.weight(1f)) { category = Category.ARCHIVES; tab = HomeTab.MY_FILES }
                            }
                        }
                        item { SectionHeading("SOURCE", "All") }
                        item {
                            Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp).background(Card, RoundedCornerShape(22.dp)).padding(12.dp), horizontalArrangement = Arrangement.SpaceAround) {
                                SourceAction("Downloads", Icons.Default.Download) { toast("Choose the Downloads folder in the folder picker"); phonePicker.launch(null) }
                                SourceAction("Share", Icons.Default.Share) { if (selection.isNotEmpty()) shareSelected() else toast("Select files in My files to share") }
                                SourceAction("Wi-Fi", Icons.Default.Wifi) { context.startActivity(Intent(android.provider.Settings.ACTION_WIFI_SETTINGS)) }
                                SourceAction("Recorder", Icons.Default.Mic) { toast("Open your installed Recorder app from Apps") }
                            }
                        }
                        item { SectionHeading("LOCAL STORAGE", "Refresh") }
                        item {
                            Column(Modifier.padding(horizontal = 20.dp).background(Card, RoundedCornerShape(24.dp)).padding(horizontal = 16.dp)) {
                                StorageRow("Phone", phoneRoot, Icons.Default.PhoneAndroid) { phonePicker.launch(null) }
                                Divider(color = Line)
                                StorageRow("USB drive", usbRoot, Icons.Default.Usb) { usbPicker.launch(null) }
                            }
                        }
                        item { SectionHeading("LOCATION", "") }
                        item {
                            Row(Modifier.padding(horizontal = 20.dp).fillMaxWidth().background(Card, RoundedCornerShape(20.dp)).clickable { toast("Safe folder will be created inside selected Phone storage") }.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Lock, null, tint = Blue, modifier = Modifier.size(28.dp)); Spacer(Modifier.width(14.dp)); Text("Safe", fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f)); Icon(Icons.Default.ChevronRight, null, tint = Subtle)
                            }
                        }
                    }
                } else {
                    if (tab == HomeTab.MY_FILES || tab == HomeTab.RECENT) {
                        SearchBox(query, { query = it }, Modifier.padding(horizontal = 20.dp, vertical = 6.dp))
                        if (dualPane && tab == HomeTab.MY_FILES) {
                            Column(Modifier.weight(1f).padding(horizontal = 14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                PaneHeader("PHONE", leftFolder, activePane == 0, Modifier.fillMaxWidth()) { activePane = 0; refresh(); if (phoneRoot == null) phonePicker.launch(null) }
                                PaneFileList(leftFolder, selection, query, onActivate = { file ->
                                    activePane = 0
                                    if (selection.isNotEmpty()) selection = if (selection.contains(file.uri.toString())) selection - file.uri.toString() else selection + file.uri.toString()
                                    else if (file.isDirectory) leftFolder = file else openFile(file)
                                }, onLongPress = { activePane = 0; selection = selection + it.uri.toString() }, onMore = { activePane = 0; showMore = it }, modifier = Modifier.weight(1f))
                                PaneHeader("USB / TARGET", rightFolder, activePane == 1, Modifier.fillMaxWidth()) { activePane = 1; refresh(); if (usbRoot == null) usbPicker.launch(null) }
                                PaneFileList(rightFolder, selection, query, onActivate = { file ->
                                    activePane = 1
                                    if (selection.isNotEmpty()) selection = if (selection.contains(file.uri.toString())) selection - file.uri.toString() else selection + file.uri.toString()
                                    else if (file.isDirectory) rightFolder = file else openFile(file)
                                }, onLongPress = { activePane = 1; selection = selection + it.uri.toString() }, onMore = { activePane = 1; showMore = it }, modifier = Modifier.weight(1f))
                            }
                        } else {
                        val visibleFiles = allFiles.filter { file ->
                            val matchesQuery = file.name.orEmpty().contains(query, true)
                            val mime = file.type ?: guessMime(file.name)
                            val matchesCategory = category == Category.ALL || when (category) {
                                Category.IMAGES -> mime.startsWith("image/")
                                Category.VIDEOS -> mime.startsWith("video/")
                                Category.AUDIO -> mime.startsWith("audio/")
                                Category.APPS -> mime == "application/vnd.android.package-archive"
                                Category.ARCHIVES -> mime.contains("zip") || file.name.orEmpty().endsWith(".rar", true) || file.name.orEmpty().endsWith(".7z", true)
                                Category.DOCS -> mime.startsWith("application/") && !mime.contains("zip") && mime != "application/vnd.android.package-archive"
                                else -> true
                            }
                            matchesQuery && matchesCategory
                        }
                        Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(currentFolder()?.name ?: "Choose storage", fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                            TextButton(onClick = { if (currentFolder() == null) phonePicker.launch(null) else { val created = currentFolder()?.createDirectory("New folder"); if (created != null) refresh() } }) { Text("+ Folder") }
                            TextButton(onClick = { dualPane = !dualPane }) { Text(if (dualPane) "Single" else "Dual") }
                        }
                        if (currentFolder() == null) {
                            Column(Modifier.fillMaxWidth().weight(1f), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                                Icon(Icons.Default.FolderOpen, null, tint = Blue, modifier = Modifier.size(58.dp))
                                Text("Select Phone or USB storage", fontWeight = FontWeight.Bold)
                                Button(onClick = { phonePicker.launch(null) }) { Text("Choose Phone folder") }
                            }
                        } else {
                            LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(horizontal = 18.dp, vertical = 6.dp)) {
                                item {
                                    Row(Modifier.fillMaxWidth().clickable {
                                        val root = if (activePane == 1) usbRoot else phoneRoot
                                        val parent = currentFolder()?.parentFile
                                        if (currentFolder()?.uri != root?.uri) { setCurrent(parent ?: root); refresh() }
                                    }.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Text("Phone", color = Blue); Icon(Icons.Default.ChevronRight, null, tint = Subtle); Text(currentFolder()?.name ?: "Storage")
                                    }
                                }
                                items(visibleFiles, key = { it.uri.toString() }) { file ->
                                    val isSelected = selection.contains(file.uri.toString())
                                    FileItem(file, isSelected, selection.isNotEmpty(), onClick = {
                                        if (selection.isNotEmpty()) selection = if (isSelected) selection - file.uri.toString() else selection + file.uri.toString()
                                        else if (file.isDirectory) { setCurrent(file); refresh() } else openFile(file)
                                    }, onLongClick = { selection = selection + file.uri.toString() }, onMore = { showMore = file })
                                }
                                if (visibleFiles.isEmpty()) item { Text("No files found", color = Subtle, modifier = Modifier.padding(24.dp)) }
                            }
                        }
                        }
                        if (selection.isNotEmpty()) {
                            Row(Modifier.fillMaxWidth().background(Card).padding(horizontal = 8.dp, vertical = 8.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                                ActionButton("Share", Icons.Default.Share) { shareSelected() }
                                ActionButton("Copy", Icons.Default.ContentCopy) { pendingTransfer = "copy"; destinationPicker.launch(null) }
                                ActionButton("Move", Icons.Default.DriveFileMove) { pendingTransfer = "move"; destinationPicker.launch(null) }
                                ActionButton("Delete", Icons.Default.Delete) {
                                    val chosen = currentFolder()?.listFiles()?.filter { selection.contains(it.uri.toString()) }.orEmpty()
                                    chosen.forEach { it.delete() }; selection = emptySet(); refresh(); toast("Deleted")
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showMore != null) {
        val file = showMore!!
        AlertDialog(onDismissRequest = { showMore = null }, title = { Text(file.name ?: "File") },
            text = { Column {
                Text("Favourite", Modifier.fillMaxWidth().clickable { notice = "Favourites are planned for a later update."; showMore = null }.padding(12.dp))
                Text("Rename", Modifier.fillMaxWidth().clickable { renameText = file.name.orEmpty(); selectedDetails = file; showRename = true; showMore = null }.padding(12.dp))
                Text("Copy", Modifier.fillMaxWidth().clickable { selection = setOf(file.uri.toString()); pendingTransfer = "copy"; destinationPicker.launch(null); showMore = null }.padding(12.dp))
                Text("Details", Modifier.fillMaxWidth().clickable { selectedDetails = file; showDetails = true; showMore = null }.padding(12.dp))
                Text("Open in app", Modifier.fillMaxWidth().clickable { openFile(file); showMore = null }.padding(12.dp))
                Text("Delete", color = MaterialTheme.colorScheme.error, modifier = Modifier.fillMaxWidth().clickable { file.delete(); showMore = null; refresh() }.padding(12.dp))
            } }, confirmButton = { TextButton(onClick = { showMore = null }) { Text("Close") } })
    }
    if (showRename && selectedDetails != null) AlertDialog(onDismissRequest = { showRename = false }, title = { Text("Rename") }, text = { OutlinedTextField(renameText, { renameText = it }, singleLine = true) }, confirmButton = {
        TextButton(onClick = { selectedDetails?.renameTo(renameText.trim()); showRename = false; refresh() }) { Text("Save") }
    }, dismissButton = { TextButton(onClick = { showRename = false }) { Text("Cancel") } })
    if (showDetails && selectedDetails != null) AlertDialog(onDismissRequest = { showDetails = false }, title = { Text("Details") }, text = {
        val f = selectedDetails!!
        Text("Name: ${f.name}\nType: ${f.type ?: guessMime(f.name)}\nSize: ${humanSize(f.length())}\nModified: ${DateFormat.getDateTimeInstance().format(Date(f.lastModified()))}\nLocation: ${f.parentFile?.name ?: "Storage"}")
    }, confirmButton = { TextButton(onClick = { showDetails = false }) { Text("OK") } })
    if (notice.isNotBlank()) AlertDialog(onDismissRequest = { notice = "" }, text = { Text(notice) }, confirmButton = { TextButton(onClick = { notice = "" }) { Text("OK") } })
}

@Composable
private fun SearchBox(value: String, onChange: (String) -> Unit, modifier: Modifier = Modifier) {
    Row(modifier.fillMaxWidth().height(58.dp).background(Color(0xFFE9EAED), RoundedCornerShape(30.dp)).padding(horizontal = 18.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Default.Search, null, tint = Subtle)
        Spacer(Modifier.width(10.dp))
        BasicTextField(value, onChange, modifier = Modifier.fillMaxWidth(), singleLine = true, decorationBox = { inner -> if (value.isEmpty()) Text("Search", color = Subtle); inner() })
    }
}

@Composable
private fun CategoryCard(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, tint: Color, modifier: Modifier, onClick: () -> Unit) {
    Column(modifier.height(116.dp).background(Card, RoundedCornerShape(22.dp)).combinedClickable(onClick = onClick).padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Icon(icon, null, tint = tint, modifier = Modifier.size(34.dp)); Spacer(Modifier.height(8.dp)); Text(label, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun SectionHeading(title: String, action: String) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 20.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(title, color = Subtle, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
        if (action.isNotBlank()) Text(action, color = Blue, style = MaterialTheme.typography.labelLarge)
    }
}

@Composable
private fun SourceAction(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    Column(Modifier.clickable(onClick = onClick).padding(5.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(icon, null, tint = Blue, modifier = Modifier.size(28.dp)); Spacer(Modifier.height(6.dp)); Text(label, style = MaterialTheme.typography.labelSmall)
    }
}

@Composable
private fun StorageRow(name: String, root: DocumentFile?, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 18.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = Blue, modifier = Modifier.size(32.dp)); Spacer(Modifier.width(16.dp))
        Column(Modifier.weight(1f)) { Text(name, fontWeight = FontWeight.Bold); Text(if (root == null) "Tap to choose storage folder" else "${root.listFiles().size} items connected", color = Subtle, style = MaterialTheme.typography.bodySmall) }
        Icon(Icons.Default.ChevronRight, null, tint = Subtle)
    }
}

@Composable
private fun PaneHeader(label: String, folder: DocumentFile?, active: Boolean, modifier: Modifier, onClick: () -> Unit) {
    Column(modifier.background(if (active) Color(0xFFE5EDFF) else Card, RoundedCornerShape(12.dp)).clickable(onClick = onClick).padding(10.dp)) {
        Text(label, color = if (active) Blue else Ink, fontWeight = FontWeight.Bold)
        Text(folder?.name ?: "Not selected", color = Subtle, style = MaterialTheme.typography.labelSmall, maxLines = 1)
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun FileItem(file: DocumentFile, selected: Boolean, selectionMode: Boolean, onClick: () -> Unit, onLongClick: () -> Unit, onMore: () -> Unit) {
    Row(Modifier.fillMaxWidth().background(if (selected) Color(0xFFEAF1FF) else Card, RoundedCornerShape(10.dp)).combinedClickable(onClick = onClick, onLongClick = onLongClick).padding(vertical = 9.dp, horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(if (file.isDirectory) Icons.Default.Folder else fileIcon(file), null, tint = if (file.isDirectory) Color(0xFF3478F6) else Color(0xFF69717F), modifier = Modifier.size(34.dp))
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(file.name ?: "Unnamed", fontWeight = FontWeight.SemiBold, maxLines = 1)
            Text(if (file.isDirectory) "Folder" else "${DateFormat.getDateInstance().format(Date(file.lastModified()))}  ·  ${humanSize(file.length())}", color = Subtle, style = MaterialTheme.typography.labelSmall, maxLines = 1)
        }
        if (selectionMode) Checkbox(checked = selected, onCheckedChange = { onClick() }) else IconButton(onClick = onMore) { Icon(Icons.Default.MoreVert, "More", tint = Subtle) }
    }
    Divider(color = Line, modifier = Modifier.padding(start = 52.dp))
}

@Composable
private fun PaneFileList(
    folder: DocumentFile?,
    selectedUris: Set<String>,
    query: String,
    onActivate: (DocumentFile) -> Unit,
    onLongPress: (DocumentFile) -> Unit,
    onMore: (DocumentFile) -> Unit,
    modifier: Modifier = Modifier
) {
    val files = folder?.listFiles()?.sortedWith(compareByDescending<DocumentFile> { it.isDirectory }.thenBy { it.name?.lowercase() }).orEmpty()
        .filter { it.name.orEmpty().contains(query, true) }
    if (folder == null) {
        Box(modifier.fillMaxWidth(), contentAlignment = Alignment.Center) { Text("Choose a folder", color = Subtle) }
    } else if (files.isEmpty()) {
        Box(modifier.fillMaxWidth(), contentAlignment = Alignment.Center) { Text("Empty folder", color = Subtle) }
    } else {
        LazyColumn(modifier.fillMaxWidth()) {
            items(files, key = { it.uri.toString() }) { file ->
                FileItem(file, selectedUris.contains(file.uri.toString()), selectedUris.isNotEmpty(), onClick = { onActivate(file) }, onLongClick = { onLongPress(file) }, onMore = { onMore(file) })
            }
        }
    }
}

@Composable
private fun ActionButton(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    TextButton(onClick = onClick) { Column(horizontalAlignment = Alignment.CenterHorizontally) { Icon(icon, null); Text(label, style = MaterialTheme.typography.labelSmall) } }
}

private fun fileIcon(file: DocumentFile): androidx.compose.ui.graphics.vector.ImageVector {
    val mime = file.type ?: guessMime(file.name)
    return when { mime.startsWith("image/") -> Icons.Default.Image; mime.startsWith("video/") -> Icons.Default.VideoFile; mime.startsWith("audio/") -> Icons.Default.AudioFile; else -> Icons.Default.InsertDriveFile }
}

private fun guessMime(name: String?): String {
    val ext = name?.substringAfterLast('.', "")?.lowercase().orEmpty()
    return MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "*/*"
}

private fun humanSize(bytes: Long): String = when {
    bytes < 1024 -> "$bytes B"
    bytes < 1024L * 1024 -> "%.1f KB".format(bytes / 1024.0)
    bytes < 1024L * 1024 * 1024 -> "%.1f MB".format(bytes / (1024.0 * 1024))
    else -> "%.2f GB".format(bytes / (1024.0 * 1024 * 1024))
}

private fun copyEntry(context: android.content.Context, source: DocumentFile, destination: DocumentFile?): Boolean {
    if (destination == null || !destination.canWrite()) return false
    return try {
        if (source.isDirectory) {
            val dir = destination.findFile(source.name ?: "Folder") ?: destination.createDirectory(source.name ?: "Folder") ?: return false
            source.listFiles().all { copyEntry(context, it, dir) }
        } else {
            val name = source.name ?: "file"
            val target = destination.createFile(source.type ?: guessMime(name), name) ?: return false
            context.contentResolver.openInputStream(source.uri).use { input ->
                context.contentResolver.openOutputStream(target.uri, "w").use { output ->
                    if (input == null || output == null) return false
                    input.copyTo(output)
                }
            }
            true
        }
    } catch (_: Exception) { false }
}

# Mapla File Manager 2.0 (starter build)

A light-theme Android file manager prototype built with Kotlin and Jetpack Compose.

## Implemented in this build
- Browse home with Images, Videos, Docs, Audio, Apps and Archives category shortcuts.
- Select a Phone storage folder and a separate USB/OTG folder using Android's Storage Access Framework.
- Browse folders and files, search within the selected folder, and show file size/date/type details.
- Multi-select, share through Android's system Sharesheet, rename, delete, and open files in installed apps.
- Copy and move selected files/folders to another folder selected through Android's folder picker.
- Dual-pane mode with independent Phone and USB/target folder views.

## Important limitations
- Android asks the user to grant access to each storage folder. This app does not silently access all storage.
- The storage cards show connected folder/item information, not a full device-wide storage analyzer.
- Wi-Fi opens Android Wi-Fi settings; wireless transfer server, Honor Share integration, archive compression/extraction, encrypted Safe vault, favourites persistence, tags and global recent-file indexing are not implemented yet.
- The Downloads shortcut asks the user to choose the Downloads folder; it does not assume unrestricted access.

## Build
Use Android Studio or the repository GitHub Actions workflow to build `:app:assembleDebug`.

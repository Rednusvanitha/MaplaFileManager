# Mapla File Manager – Android starter v3

A lightweight Android file browser built with Kotlin and Jetpack Compose.

## Build
- JDK 17
- Android SDK platform 35
- Gradle 8.9
- Run: `gradle --no-daemon assembleDebug`

## Storage access
On first launch, tap **Choose folder** and select Internal Storage (or a USB OTG folder) in Android's system folder picker. Approve access. The app then lists the selected folder's contents and lets you open folders, search names, filter common file categories, open files with installed apps, and share files using Android's share sheet.

Android requires the user to grant folder access. This app does not silently scan the phone. Choose the internal storage root once for broad access; choose the USB drive separately when connected.

This is an early starter build, not a full Solid Explorer replacement. Copy/move/rename/delete, dual-pane browsing, archive extraction, Wi-Fi transfer and background media indexing are not implemented yet.

package com.mapla.filemanager

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Archive
import androidx.compose.material.icons.filled.AudioFile
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.VideoFile
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.documentfile.provider.DocumentFile
import java.text.DecimalFormat

private val Ink = Color(0xFF171923)
private val Purple = Color(0xFF7655E8)
private val Pale = Color(0xFFF3F4F8)

class MainActivity : ComponentActivity() {
    private var selectedTree by mutableStateOf<Uri?>(null)
    private val folderPicker = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
            selectedTree = uri
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = lightColorScheme(primary = Purple, background = Pale)) {
                FileManagerHome(
                    rootUri = selectedTree,
                    onChooseFolder = { folderPicker.launch(null) },
                    onShare = { uri, name ->
                        val send = Intent(Intent.ACTION_SEND).apply {
                            type = contentResolver.getType(uri) ?: "*/*"
                            putExtra(Intent.EXTRA_STREAM, uri)
                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        }
                        startActivity(Intent.createChooser(send, "Share $name"))
                    }
                )
            }
        }
    }
}

@Composable
private fun FileManagerHome(rootUri: Uri?, onChooseFolder: () -> Unit, onShare: (Uri, String) -> Unit) {
    val context = androidx.compose.ui.platform.LocalContext.current
    var current by remember(rootUri) { mutableStateOf(rootUri?.let { DocumentFile.fromTreeUri(context, it) }) }
    var search by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("All") }
    LaunchedEffect(rootUri) { current = rootUri?.let { DocumentFile.fromTreeUri(context, it) } }
    val children = remember(current) { current?.listFiles()?.sortedWith(compareBy<DocumentFile> { !it.isDirectory }.thenBy { it.name?.lowercase() ?: "" }) ?: emptyList() }
    val visible = children.filter { file ->
        val n = file.name.orEmpty()
        val ext = n.substringAfterLast('.', "").lowercase()
        val matchesCategory = when (category) {
            "Images" -> ext in setOf("jpg", "jpeg", "png", "gif", "webp", "bmp", "heic")
            "Videos" -> ext in setOf("mp4", "mkv", "mov", "avi", "webm", "3gp")
            "Docs" -> ext in setOf("pdf", "doc", "docx", "txt", "xls", "xlsx", "ppt", "pptx")
            "Audio" -> ext in setOf("mp3", "m4a", "wav", "aac", "ogg", "flac")
            "Archives" -> ext in setOf("zip", "rar", "7z", "tar", "gz")
            else -> true
        }
        matchesCategory && n.contains(search, ignoreCase = true)
    }

    Scaffold(containerColor = Pale, bottomBar = {
        NavigationBar(containerColor = Color.White) {
            NavigationBarItem(selected = category == "Recent", onClick = { category = "Recent" }, icon = { Icon(Icons.Default.Description, null) }, label = { Text("Recent") })
            NavigationBarItem(selected = category == "All", onClick = { category = "All" }, icon = { Icon(Icons.Default.Folder, null) }, label = { Text("My files") })
            NavigationBarItem(selected = category == "Browse", onClick = { category = "Browse" }, icon = { Icon(Icons.Default.Folder, null) }, label = { Text("Browse") })
        }
    }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 18.dp)) {
            Row(Modifier.fillMaxWidth().padding(top = 18.dp, bottom = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(if (current?.name != null) current?.name!! else "Browse", fontSize = 26.sp, color = Ink, modifier = Modifier.weight(1f))
                Text("＋", fontSize = 30.sp, color = Ink, modifier = Modifier.clickable { onChooseFolder() }.padding(horizontal = 12.dp))
                Text("⋮", fontSize = 28.sp, color = Ink)
            }
            OutlinedTextField(value = search, onValueChange = { search = it }, modifier = Modifier.fillMaxWidth(), placeholder = { Text("Search files and folders") }, leadingIcon = { Icon(Icons.Default.Search, null) }, shape = RoundedCornerShape(32.dp), singleLine = true)
            Spacer(Modifier.height(16.dp))
            Text("CATEGORIES", color = Color.Gray, fontSize = 12.sp)
            Spacer(Modifier.height(8.dp))
            val cats = listOf(Triple("Images", Icons.Default.Image, Color(0xFF2687E8)), Triple("Videos", Icons.Default.VideoFile, Color(0xFFFF9B20)), Triple("Docs", Icons.Default.Description, Color(0xFF21A66B)), Triple("Audio", Icons.Default.AudioFile, Color(0xFF8054D8)), Triple("Archives", Icons.Default.Archive, Color(0xFFEB7135)))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                cats.take(3).forEach { (name, icon, tint) -> CategoryTile(name, icon, tint, Modifier.weight(1f)) { category = name } }
            }
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                cats.drop(3).forEach { (name, icon, tint) -> CategoryTile(name, icon, tint, Modifier.weight(1f)) { category = name } }
                Spacer(Modifier.weight(1f))
            }
            Spacer(Modifier.height(18.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("LOCAL STORAGE", color = Color.Gray, fontSize = 12.sp, modifier = Modifier.weight(1f))
                Text("Choose / Refresh", color = Purple, modifier = Modifier.clickable { onChooseFolder() })
            }
            Spacer(Modifier.height(10.dp))
            if (rootUri == null) {
                Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(22.dp), modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.Folder, null, tint = Purple, modifier = Modifier.size(64.dp))
                        Text("Welcome, Mapla!", color = Ink, fontSize = 20.sp)
                        Text("Choose Internal Storage or your USB OTG drive", color = Color.Gray)
                        Button(onClick = onChooseFolder, modifier = Modifier.padding(top = 14.dp)) { Text("Choose folder") }
                    }
                }
            } else {
                Text("${visible.size} items", color = Color.Gray, fontSize = 12.sp, modifier = Modifier.padding(vertical = 8.dp))
                LazyColumn(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    items(visible, key = { it.uri.toString() }) { file ->
                        FileRow(file = file, onOpen = { if (file.isDirectory) current = file else openFile(context, file) }, onShare = { onShare(file.uri, file.name ?: "file") })
                    }
                }
            }
        }
    }
}

@Composable
private fun CategoryTile(name: String, icon: ImageVector, tint: Color, modifier: Modifier, onClick: () -> Unit) {
    Card(modifier = modifier.height(88.dp).clickable(onClick = onClick), colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Icon(icon, null, tint = tint, modifier = Modifier.size(30.dp))
            Spacer(Modifier.height(5.dp)); Text(name, color = Ink, fontSize = 13.sp)
        }
    }
}

@Composable
private fun FileRow(file: DocumentFile, onOpen: () -> Unit, onShare: () -> Unit) {
    Row(Modifier.fillMaxWidth().background(Color.White).clickable(onClick = onOpen).padding(vertical = 12.dp, horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(if (file.isDirectory) Icons.Default.Folder else Icons.Default.Description, null, tint = if (file.isDirectory) Color(0xFFE8B83F) else Purple, modifier = Modifier.size(38.dp))
        Column(Modifier.weight(1f).padding(start = 12.dp)) {
            Text(file.name ?: "Unnamed", color = Ink, maxLines = 1)
            Text(if (file.isDirectory) "Folder" else formatSize(file.length()), color = Color.Gray, fontSize = 12.sp)
        }
        Text("Share", color = Purple, fontSize = 12.sp, modifier = Modifier.clickable { onShare() }.padding(8.dp))
    }
    HorizontalDivider(color = Color(0xFFE6E6E6))
}

private fun formatSize(bytes: Long): String {
    if (bytes <= 0) return "File"
    val units = arrayOf("B", "KB", "MB", "GB")
    var size = bytes.toDouble(); var index = 0
    while (size >= 1024 && index < units.lastIndex) { size /= 1024; index++ }
    return "${DecimalFormat("#0.##").format(size)} ${units[index]}"
}

private fun openFile(context: android.content.Context, file: DocumentFile) {
    val intent = Intent(Intent.ACTION_VIEW).apply {
        setDataAndType(file.uri, context.contentResolver.getType(file.uri) ?: "*/*")
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    runCatching { context.startActivity(intent) }
}

package com.mapla.filemanager

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.StatFs
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.documentfile.provider.DocumentFile
import java.text.DecimalFormat

private val Purple = Color(0xFF7655E8)
private val Pale = Color(0xFFF2F3F8)
private val Ink = Color(0xFF171923)
private data class FileEntry(val name: String, val uri: Uri, val mime: String?, val size: Long, val date: Long)

class MainActivity : ComponentActivity() {
    private var refreshKey by mutableIntStateOf(0)
    private val permissions = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { refreshKey++ }
    private val folderPicker = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
            getSharedPreferences("mfm", MODE_PRIVATE).edit().putString("tree", uri.toString()).apply()
            refreshKey++
        }
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = lightColorScheme(primary = Purple, background = Pale)) {
                FileManagerHome(refreshKey, onChooseFolder = { folderPicker.launch(null) }, onRequestPermissions = {
                    val p = if (Build.VERSION.SDK_INT >= 33) arrayOf(Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.READ_MEDIA_VIDEO, Manifest.permission.READ_MEDIA_AUDIO) else arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
                    permissions.launch(p)
                })
            }
        }
    }
}

@Composable
private fun FileManagerHome(refreshKey: Int, onChooseFolder: () -> Unit, onRequestPermissions: () -> Unit) {
    val context = LocalContext.current
    var section by remember { mutableStateOf("Browse") }
    var category by remember { mutableStateOf("All") }
    var search by remember { mutableStateOf("") }
    var entries by remember { mutableStateOf(emptyList<FileEntry>()) }
    var root by remember { mutableStateOf<DocumentFile?>(null) }
    val prefs = remember { context.getSharedPreferences("mfm", Context.MODE_PRIVATE) }
    val treeString = prefs.getString("tree", null)
    var permissionPrompted by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        val p = if (Build.VERSION.SDK_INT >= 33) listOf(Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.READ_MEDIA_VIDEO, Manifest.permission.READ_MEDIA_AUDIO) else listOf(Manifest.permission.READ_EXTERNAL_STORAGE)
        if (!permissionPrompted && p.any { ContextCompat.checkSelfPermission(context, it) != PackageManager.PERMISSION_GRANTED }) {
            permissionPrompted = true
            onRequestPermissions()
        }
    }
    LaunchedEffect(refreshKey, category, treeString) {
        val needed = if (Build.VERSION.SDK_INT >= 33) listOf(Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.READ_MEDIA_VIDEO, Manifest.permission.READ_MEDIA_AUDIO) else listOf(Manifest.permission.READ_EXTERNAL_STORAGE)
        val granted = needed.all { ContextCompat.checkSelfPermission(context, it) == PackageManager.PERMISSION_GRANTED }
        if (!granted) { entries = emptyList() } else {
            entries = queryMedia(context.contentResolver, category)
        }
        root = treeString?.let { DocumentFile.fromTreeUri(context, Uri.parse(it)) }
    }
    val filtered = entries.filter { it.name.contains(search, true) }
    val folderFiles = remember(root, refreshKey) { root?.listFiles()?.toList().orEmpty() }
    val stat = remember(refreshKey) { runCatching { StatFs(Environment.getExternalStorageDirectory().path) }.getOrNull() }
    val total = stat?.totalBytes ?: 0L
    val free = stat?.availableBytes ?: 0L

    Scaffold(containerColor = Pale, bottomBar = {
        NavigationBar(containerColor = Color.White) {
            NavigationBarItem(section == "Recent", { section = "Recent"; category = "Recent" }, icon = { Icon(Icons.Default.History, null) }, label = { Text("Recent") })
            NavigationBarItem(section == "My files", { section = "My files"; category = "All" }, icon = { Icon(Icons.Default.Folder, null) }, label = { Text("My files") })
            NavigationBarItem(section == "Browse", { section = "Browse"; category = "All" }, icon = { Icon(Icons.Default.FolderOpen, null) }, label = { Text("Browse") })
        }
    }) { pad ->
        LazyColumn(Modifier.fillMaxSize().padding(pad).padding(horizontal = 18.dp), contentPadding = PaddingValues(bottom = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item {
                Row(Modifier.fillMaxWidth().padding(top = 18.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(if (section == "Browse") "Browse" else section, fontSize = 25.sp, fontWeight = FontWeight.Bold, color = Ink, modifier = Modifier.weight(1f))
                    IconButton(onClick = onChooseFolder) { Icon(Icons.Default.Add, null, tint = Ink) }
                    IconButton(onClick = onRequestPermissions) { Icon(Icons.Default.MoreVert, null, tint = Ink) }
                }
                OutlinedTextField(search, { search = it }, Modifier.fillMaxWidth(), placeholder = { Text("Search files and folders") }, leadingIcon = { Icon(Icons.Default.Search, null) }, shape = RoundedCornerShape(32.dp), singleLine = true)
            }
            item { Text("CATEGORIES", color = Color.Gray, fontSize = 12.sp, fontWeight = FontWeight.Bold) }
            item {
                val cats = listOf(Triple("Images", Icons.Default.Image, Color(0xFF2687E8)), Triple("Videos", Icons.Default.VideoFile, Color(0xFFFF9B20)), Triple("Docs", Icons.Default.Description, Color(0xFF21A66B)), Triple("Audio", Icons.Default.AudioFile, Color(0xFF8054D8)), Triple("Apps", Icons.Default.Android, Color(0xFF25B7B2)), Triple("Archives", Icons.Default.Archive, Color(0xFFEB7135)))
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { cats.take(3).forEach { (n,i,c) -> CategoryTile(n,i,c,Modifier.weight(1f)){ category=n; section="My files" } } }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { cats.drop(3).forEach { (n,i,c) -> CategoryTile(n,i,c,Modifier.weight(1f)){ category=n; section="My files" } } }
                }
            }
            item {
                Row(verticalAlignment = Alignment.CenterVertically) { Text("SOURCE", color = Color.Gray, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f)); Text("All  ›", color = Color.Gray) }
                Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(22.dp)) {
                    Row(Modifier.fillMaxWidth().padding(vertical = 14.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                        SourceItem("Downloads", Icons.Default.Download) { category="All"; section="My files" }
                        SourceItem("Share", Icons.Default.Share) { }
                        SourceItem("Wi-Fi", Icons.Default.Wifi) { }
                        SourceItem("Recorder", Icons.Default.Mic) { }
                    }
                }
            }
            item {
                Row(verticalAlignment = Alignment.CenterVertically) { Text("LOCAL STORAGE", color = Color.Gray, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f)); Text("Refresh", color = Purple, modifier = Modifier.clickable { onRequestPermissions() }) }
                Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(22.dp), modifier = Modifier.fillMaxWidth().clickable { if (root == null) onChooseFolder() else { category="All"; section="My files" } }) {
                    Row(Modifier.fillMaxWidth().padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.PhoneAndroid, null, tint = Color(0xFF4885E8), modifier = Modifier.size(36.dp))
                        Column(Modifier.weight(1f).padding(start = 16.dp)) { Text("Phone", color = Ink, fontWeight = FontWeight.Bold); Text(if (total > 0) "${formatSize(free)} Available / ${formatSize(total)}" else "Tap to access files", color = Color.Gray, fontSize = 13.sp) }
                        Icon(Icons.Default.ChevronRight, null, tint = Color.Gray)
                    }
                }
            }
            item {
                Text("LOCATION", color = Color.Gray, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(22.dp)) {
                    Column {
                        Row(Modifier.fillMaxWidth().clickable { }.padding(18.dp), verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.Lock, null, tint = Color(0xFF20A6D8)); Text("Safe", Modifier.weight(1f).padding(start = 16.dp), color = Ink); Icon(Icons.Default.ChevronRight, null, tint = Color.Gray) }
                        HorizontalDivider(color = Pale)
                        Row(Modifier.fillMaxWidth().clickable { }.padding(18.dp), verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.Delete, null, tint = Color(0xFFE64B4B)); Text("Recently deleted", Modifier.weight(1f).padding(start = 16.dp), color = Ink); Icon(Icons.Default.ChevronRight, null, tint = Color.Gray) }
                    }
                }
            }
            if (section != "Browse") {
                item { Text(if (category == "All") "MY FILES" else category.uppercase(), color = Color.Gray, fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                if (filtered.isEmpty()) item { Text("No files found yet. Allow file access or choose a folder.", color = Color.Gray, modifier = Modifier.padding(12.dp)) }
                items(filtered, key = { it.uri.toString() }) { f -> FileEntryRow(f) }
            }
            if (root != null && section == "My files") {
                items(folderFiles, key = { it.uri.toString() }) { f -> Row(Modifier.fillMaxWidth().background(Color.White).padding(12.dp), verticalAlignment = Alignment.CenterVertically) { Icon(if(f.isDirectory) Icons.Default.Folder else Icons.Default.InsertDriveFile,null,tint=Purple); Text(f.name ?: "Unnamed", Modifier.padding(start=12.dp), color=Ink) } }
            }
        }
    }
}

private fun queryMedia(resolver: android.content.ContentResolver, category: String): List<FileEntry> {
    val (uri, selection) = when (category) {
        "Images" -> MediaStore.Images.Media.EXTERNAL_CONTENT_URI to null
        "Videos" -> MediaStore.Video.Media.EXTERNAL_CONTENT_URI to null
        "Audio" -> MediaStore.Audio.Media.EXTERNAL_CONTENT_URI to null
        "Docs" -> MediaStore.Files.getContentUri("external") to "${MediaStore.Files.FileColumns.MIME_TYPE} IN ('application/pdf','text/plain','application/msword','application/vnd.openxmlformats-officedocument.wordprocessingml.document')"
        "Archives" -> MediaStore.Files.getContentUri("external") to "${MediaStore.Files.FileColumns.MIME_TYPE} IN ('application/zip','application/x-rar-compressed','application/x-7z-compressed')"
        else -> MediaStore.Files.getContentUri("external") to null
    }
    val result = mutableListOf<FileEntry>()
    runCatching {
        resolver.query(uri, arrayOf(MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DISPLAY_NAME, MediaStore.MediaColumns.MIME_TYPE, MediaStore.MediaColumns.SIZE, MediaStore.MediaColumns.DATE_MODIFIED), selection, null, "${MediaStore.MediaColumns.DATE_MODIFIED} DESC")?.use { c ->
            val id = c.getColumnIndexOrThrow(MediaStore.MediaColumns._ID); val name = c.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME); val mime = c.getColumnIndex(MediaStore.MediaColumns.MIME_TYPE); val size = c.getColumnIndex(MediaStore.MediaColumns.SIZE); val date = c.getColumnIndex(MediaStore.MediaColumns.DATE_MODIFIED)
            while (c.moveToNext()) { val itemUri = Uri.withAppendedPath(uri, c.getLong(id).toString()); result.add(FileEntry(c.getString(name) ?: "File", itemUri, if(mime>=0)c.getString(mime) else null, if(size>=0)c.getLong(size) else 0L, if(date>=0)c.getLong(date) else 0L)) }
        }
    }
    return result
}

@Composable private fun CategoryTile(name:String, icon:ImageVector, tint:Color, modifier:Modifier, onClick:()->Unit) {
    Card(modifier.height(96.dp).clickable(onClick=onClick), colors=CardDefaults.cardColors(containerColor=Color.White), shape=RoundedCornerShape(20.dp)) { Column(Modifier.fillMaxSize(), horizontalAlignment=Alignment.CenterHorizontally, verticalArrangement=Arrangement.Center) { Icon(imageVector = icon, contentDescription = name, modifier = Modifier.size(34.dp), tint = tint); Spacer(Modifier.height(7.dp)); Text(name,color=Ink,fontWeight=FontWeight.SemiBold,fontSize=13.sp) } }
}
@Composable private fun SourceItem(name:String, icon:ImageVector, onClick:()->Unit) { Column(Modifier.clickable(onClick=onClick).padding(horizontal=8.dp), horizontalAlignment=Alignment.CenterHorizontally) { Icon(icon,null,tint=Color(0xFF367BE5),modifier=Modifier.size(30.dp)); Text(name,fontSize=11.sp,color=Ink) } }
@Composable private fun FileEntryRow(file:FileEntry) { val context= LocalContext.current; Row(Modifier.fillMaxWidth().background(Color.White).clickable { val i=Intent(Intent.ACTION_VIEW).apply{setDataAndType(file.uri,file.mime ?: "*/*");addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)};runCatching{context.startActivity(i)} }.padding(12.dp),verticalAlignment=Alignment.CenterVertically) { Icon(Icons.Default.InsertDriveFile,null,tint=Purple,modifier=Modifier.size(32.dp)); Column(Modifier.weight(1f).padding(start=12.dp)) { Text(file.name,color=Ink,maxLines=1); Text(formatSize(file.size),color=Color.Gray,fontSize=12.sp) } }; HorizontalDivider(color=Pale) }
private fun formatSize(bytes:Long):String { if(bytes<=0)return "0 B"; val units=arrayOf("B","KB","MB","GB","TB");var n=bytes.toDouble();var i=0;while(n>=1024&&i<units.lastIndex){n/=1024;i++};return "${DecimalFormat("#0.##").format(n)} ${units[i]}" }

# Mapla File Manager v4

Android starter project with a Solid Explorer-inspired Browse home screen, media category tiles, local storage summary, source shortcuts, and bottom navigation.

## Current capabilities
- Requests Android media permissions and automatically lists indexed images, videos, audio, documents, and archives where Android exposes them through MediaStore.
- Shows phone storage capacity and available space.
- Allows the user to select a storage folder once through Android's Storage Access Framework and remembers that selection.
- Opens indexed files using compatible installed apps.

## Android storage note
Android's scoped-storage rules do not let ordinary apps silently browse every folder. Images/videos/audio are indexed through MediaStore after permission. For full access to arbitrary folders and USB OTG, the user must grant the folder/drive through the system folder picker. This starter does not yet implement copy/move/rename/delete, Safe, Recently Deleted, Wi-Fi transfer, or full dual-pane file operations.

Build with `gradle assembleDebug` using JDK 17 and Android SDK 35.

# Mapla File Manager (Android starter project)

Premium-dark native Android starter app using Kotlin + Jetpack Compose.

## Included in this first build
- Browse a user-selected storage folder using Android's Storage Access Framework.
- Select internal-storage folders or a USB OTG volume through the system folder picker (availability depends on the device/file system).
- Search visible files and folders.
- Create folders.
- Open folders and view file details.
- Share a selected file through Android's system share sheet (Bluetooth / Quick Share / compatible apps appear when available).
- Delete a selected file.

## Build
1. Open this folder in Android Studio (Ladybug or newer recommended).
2. Allow Gradle sync and install the Android SDK platform 35 if prompted.
3. Connect your Android phone with USB debugging enabled, or use an emulator.
4. Press Run.

## Important scope notes
This is a working starter/MVP source project, not a signed APK. It does not yet implement a dedicated Wi-Fi transfer server, batch copy/move with progress, archive extraction, recycle bin, or storage analytics. USB access is through Android's system folder picker and requires the user to grant access. Bluetooth sharing is delegated to Android's share sheet and depends on the device's available share targets.

## Build APK from a phone using GitHub Actions
1. Sign in to GitHub in your mobile browser and create a new **public** or **private** repository named `MaplaFileManager`.
2. Upload the contents of this project folder (including the hidden `.github/workflows/android-build.yml` file) to the repository root.
3. Open the repository's **Actions** tab, select **Build Mapla File Manager APK**, and tap **Run workflow** if it has not started automatically.
4. When the run finishes, open it and download the artifact named `Mapla-File-Manager-debug-apk`. Extract it and install `app-debug.apk` on your Android phone. You may need to allow installation from that browser/files app.

This workflow builds a debug APK in GitHub's cloud; it does not sign a Play Store release. The current app remains an MVP: USB access uses Android's folder picker, and sharing uses Android's share sheet. Dedicated Wi-Fi transfer, multi-file progress, archive extraction, recycle bin, and storage analytics are not implemented yet.

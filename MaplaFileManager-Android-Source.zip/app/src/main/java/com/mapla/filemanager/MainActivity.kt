package com.mapla.filemanager

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.documentfile.provider.DocumentFile
import java.text.DateFormat
import java.util.Date

private val Bg = Color(0xFF0B0D12)
private val Panel = Color(0xFF171B24)
private val Accent = Color(0xFF9B7BFF)
private val Muted = Color(0xFF9AA3B2)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaplaApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun MaplaApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    var rootUri by remember { mutableStateOf<Uri?>(null) }
    var current by remember { mutableStateOf<DocumentFile?>(null) }
    var entries by remember { mutableStateOf<List<DocumentFile>>(emptyList()) }
    var query by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("Choose a storage folder to get started") }
    var showCreate by remember { mutableStateOf(false) }
    var newFolder by remember { mutableStateOf("") }
    var selected by remember { mutableStateOf<DocumentFile?>(null) }

    fun refresh(folder: DocumentFile?) {
        current = folder
        entries = folder?.listFiles()?.sortedWith(compareByDescending<DocumentFile> { it.isDirectory }.thenBy { it.name?.lowercase() }) ?: emptyList()
        message = if (folder == null) "Choose a storage folder to get started" else "${entries.size} items"
    }

    val folderPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            runCatching {
                context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
            }
            rootUri = uri
            refresh(DocumentFile.fromTreeUri(context, uri))
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(primary = Accent, background = Bg, surface = Panel)) {
        Scaffold(containerColor = Bg, topBar = {
            TopAppBar(
                title = { Column { Text("MAPLA FILE MANAGER", fontWeight = FontWeight.ExtraBold); Text("PREMIUM DARK", color = Muted, style = MaterialTheme.typography.labelSmall) } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Bg, titleContentColor = Color.White),
                actions = { IconButton(onClick = { folderPicker.launch(null) }) { Icon(Icons.Default.FolderOpen, "Choose storage", tint = Accent) } }
            )
        }, floatingActionButton = {
            FloatingActionButton(onClick = { showCreate = true }, containerColor = Accent, contentColor = Color.White) { Icon(Icons.Default.CreateNewFolder, "Create folder") }
        }) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    StatCard("ITEMS", entries.size.toString(), Modifier.weight(1f))
                    StatCard("STORAGE", if (rootUri == null) "—" else "Connected", Modifier.weight(1f))
                }
                Spacer(Modifier.height(14.dp))
                OutlinedTextField(value = query, onValueChange = { query = it }, modifier = Modifier.fillMaxWidth(), singleLine = true,
                    placeholder = { Text("Search files and folders", color = Muted) }, leadingIcon = { Icon(Icons.Default.Search, null) },
                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Accent, unfocusedBorderColor = Panel, focusedTextColor = Color.White, unfocusedTextColor = Color.White))
                Spacer(Modifier.height(10.dp))
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text(current?.name ?: "My Files", color = Color.White, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    TextButton(onClick = { folderPicker.launch(null) }) { Text("Select storage") }
                }
                Text(message, color = Muted, style = MaterialTheme.typography.labelSmall)
                Spacer(Modifier.height(8.dp))
                if (current == null) {
                    Column(Modifier.fillMaxWidth().weight(1f), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                        Icon(Icons.Default.Folder, null, tint = Accent, modifier = Modifier.size(64.dp))
                        Spacer(Modifier.height(12.dp)); Text("Welcome, Mapla!", color = Color.White, fontWeight = FontWeight.Bold)
                        Text("Select Internal Storage or your USB OTG drive.", color = Muted)
                        Spacer(Modifier.height(14.dp)); Button(onClick = { folderPicker.launch(null) }) { Text("Choose folder") }
                    }
                } else {
                    LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        if (current != null && current != rootDocument(rootUri, context)) {
                            item { FileRow("..  Back", "Go to parent folder", true, null) { refresh(rootDocument(rootUri, context)) } }
                        }
                        items(entries.filter { it.name.orEmpty().contains(query, ignoreCase = true) }, key = { it.uri.toString() }) { file ->
                            FileRow(file.name ?: "Unnamed", if (file.isDirectory) "Folder" else formatSize(file.length()), file.isDirectory, file) {
                                if (file.isDirectory) refresh(file) else selected = file
                            }
                        }
                    }
                }
                Row(Modifier.fillMaxWidth().padding(vertical = 10.dp), horizontalArrangement = Arrangement.SpaceAround) {
                    NavAction("Files", Icons.Default.Folder) { refresh(rootDocument(rootUri, context)) }
                    NavAction("USB / OTG", Icons.Default.Usb) { folderPicker.launch(null) }
                    NavAction("Share", Icons.Default.Share) {
                        val f = selected
                        if (f != null) {
                            val send = Intent(Intent.ACTION_SEND).apply { type = "*/*"; putExtra(Intent.EXTRA_STREAM, f.uri); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION) }
                            context.startActivity(Intent.createChooser(send, "Share with"))
                        } else message = "Open a file, then use Share from its details"
                    }
                }
            }
        }
        if (showCreate) AlertDialog(onDismissRequest = { showCreate = false }, title = { Text("New folder") },
            text = { OutlinedTextField(value = newFolder, onValueChange = { newFolder = it }, label = { Text("Folder name") }) },
            confirmButton = { TextButton(onClick = {
                val name = newFolder.trim()
                if (name.isNotEmpty() && current?.createDirectory(name) != null) refresh(current)
                newFolder = ""; showCreate = false
            }) { Text("Create") } }, dismissButton = { TextButton(onClick = { showCreate = false }) { Text("Cancel") } })
        selected?.let { file ->
            AlertDialog(onDismissRequest = { selected = null }, title = { Text(file.name ?: "File") },
                text = { Text("${formatSize(file.length())}\n${file.type ?: "Unknown type"}") },
                confirmButton = { TextButton(onClick = {
                    val send = Intent(Intent.ACTION_SEND).apply { type = file.type ?: "*/*"; putExtra(Intent.EXTRA_STREAM, file.uri); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION) }
                    context.startActivity(Intent.createChooser(send, "Share file")); selected = null
                }) { Text("Share") } },
                dismissButton = { TextButton(onClick = { file.delete(); selected = null; refresh(current) }) { Text("Delete") } })
        }
    }
}

@Composable private fun StatCard(label: String, value: String, modifier: Modifier = Modifier) {
    Column(modifier.background(Panel, RoundedCornerShape(16.dp)).padding(14.dp)) { Text(label, color = Muted, style = MaterialTheme.typography.labelSmall); Text(value, color = Color.White, fontWeight = FontWeight.Bold) }
}

@Composable private fun FileRow(name: String, detail: String, isFolder: Boolean, file: DocumentFile?, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(14.dp)).clickable(onClick = onClick).padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(if (isFolder) Icons.Default.Folder else Icons.Default.InsertDriveFile, null, tint = if (isFolder) Accent else Muted, modifier = Modifier.size(28.dp))
        Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)) { Text(name, color = Color.White, fontWeight = FontWeight.Medium); Text(detail, color = Muted, style = MaterialTheme.typography.labelSmall) }
        Icon(Icons.Default.ChevronRight, null, tint = Muted)
    }
}

@Composable private fun NavAction(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    TextButton(onClick = onClick) { Icon(icon, null, modifier = Modifier.size(17.dp)); Spacer(Modifier.width(5.dp)); Text(label) }
}

private fun rootDocument(uri: Uri?, context: android.content.Context): DocumentFile? = uri?.let { DocumentFile.fromTreeUri(context, it) }
private fun formatSize(bytes: Long): String = when { bytes < 1024 -> "$bytes B"; bytes < 1024 * 1024 -> "%.1f KB".format(bytes / 1024.0); bytes < 1024L * 1024 * 1024 -> "%.1f MB".format(bytes / (1024.0 * 1024)); else -> "%.2f GB".format(bytes / (1024.0 * 1024 * 1024)) }
